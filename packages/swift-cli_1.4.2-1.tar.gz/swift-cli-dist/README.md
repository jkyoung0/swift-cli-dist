swift-cli-dist
==============

a distribution repo for openstack swift command-line tool